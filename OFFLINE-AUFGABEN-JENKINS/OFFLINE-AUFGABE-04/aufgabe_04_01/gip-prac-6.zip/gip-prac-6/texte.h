#pragma once
#include <string>
//#include <iostream>
// using namespace std;
void spalte_ab_erstem(char zeichen, std::string eingabe, std::string &erster_teil, std::string &zweiter_teil);
std::string trimme(std::string s);
